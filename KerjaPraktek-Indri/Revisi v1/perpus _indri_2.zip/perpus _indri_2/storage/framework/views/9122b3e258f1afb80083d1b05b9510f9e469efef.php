<?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr data-id="<?php echo e($d->id_cart); ?>">
    <td ><?php echo e($d->isbn); ?></td>
    <td class="fbarcode"><?php echo e($d->judul); ?></td>
    <td><?php echo e($d->nama_kategori_buku); ?></td>
    <td id="qty" style="text-align:center;"><?= $d->qty ?></td>
    <td >
        <button id="hapus-item-cart" data-bukuid="<?php echo e($d->id_buku); ?>" data-cartid="<?php echo e($d->id_cart); ?>" data-url="<?php echo e(route('cart.destroy', $d->id_cart)); ?>" data-token="<?php echo e(@csrf_token()); ?>" class="btn btn-sm btn-danger">Hapus</button>
    </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH D:\Project Freelance\Teman\KerjaPraktek-Indri\perpus _indri_2\resources\views/transaksi/cart.blade.php ENDPATH**/ ?>