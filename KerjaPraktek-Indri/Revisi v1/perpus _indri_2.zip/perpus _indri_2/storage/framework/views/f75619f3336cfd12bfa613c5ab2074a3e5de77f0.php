<script src="<?php echo e(asset('vendor/sweetalert/sweetalert.all.js')); ?>"></script>
<?php if(Session::has('alert.config')): ?>
    <script>
        Swal.fire(<?php echo Session::pull('alert.config'); ?>);
    </script>
<?php endif; ?>
<?php /**PATH D:\Project Freelance\Teman\KerjaPraktek-Indri\Revisi v1\perpus _indri_2\vendor\realrashid\sweet-alert\src/Views/alert.blade.php ENDPATH**/ ?>