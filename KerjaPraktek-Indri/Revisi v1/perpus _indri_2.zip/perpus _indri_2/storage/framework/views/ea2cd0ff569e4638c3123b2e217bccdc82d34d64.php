<ul class="nav">
  <li class="nav-item nav-profile">
    <div class="nav-link">
      <div class="user-wrapper">
        <div class="profile-image">
          <?php if(Auth::user()->gambar == ''): ?>
          <img src="<?php echo e(asset('images/user/usersss.png')); ?>" alt="profile image">
          <?php else: ?>
          <img src="<?php echo e(asset('images/user/'. Auth::user()->gambar)); ?>" height="125" width="125" alt="profile image">
          <?php endif; ?>
        </div>
      </div>
    </div>
  </li>
  <li class="nav-item">
    <a class="nav-link">
      <div class="text">
        <p class="profile-name"><?php echo e(Auth::user()->name); ?></p>
        <div>
          <small class="designation text-muted" style="text-transform: uppercase;letter-spacing: 1px;"><?php echo e(Auth::user()->level); ?></small>
          <span class="status-indicator online"></span>
        </div>
      </div>
    </a>
  </li>
  <li class="nav-item <?php echo e(setActive(['/', 'home'])); ?>">
    <a class="nav-link" href="<?php echo e(url('/')); ?>">
      <i class="menu-icon mdi mdi-home"></i>
      <span class="menu-title">Dashboard</span>
    </a>
  </li>
  <?php if(Auth::user()->level == 'admin'): ?>
  <li class="nav-item <?php echo e(setActive(['mahasiswa*', 'buku*', 'user*'])); ?>">
    <a class="nav-link " data-toggle="collapse" href="#ui-basic" aria-expanded="false" aria-controls="ui-basic">
      <i class="menu-icon mdi mdi-folder-multiple"></i>
      <span class="menu-title">Master Data</span>
      <i class="menu-arrow"></i>
    </a>
    <div class="collapse <?php echo e(setShow(['mahasiswa*', 'buku*', 'user*'])); ?>" id="ui-basic">
      <ul class="nav flex-column sub-menu">
        <li class="nav-item">
          <a class="nav-link <?php echo e(setActive(['mahasiswa*'])); ?>" href="<?php echo e(route('mahasiswa.index')); ?>">
            <i class="menu-icon mdi mdi-human-male-female"></i>Data Mahasiswa
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php echo e(setActive(['dosen*'])); ?>" href="<?php echo e(route('dosen.index')); ?>">
            <i class="menu-icon mdi mdi-human-male-female"></i>Data Dosen
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php echo e(setActive(['kategori*'])); ?>" href="<?php echo e(route('kategori.index')); ?>">
            <i class="menu-icon mdi mdi-book-multiple"></i>Kategori Buku
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php echo e(setActive(['buku*'])); ?>" href="<?php echo e(route('buku.index')); ?>">
            <i class="menu-icon mdi mdi-book-open-page-variant"></i>Data Buku
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php echo e(setActive(['user*'])); ?>" href="<?php echo e(route('user.index')); ?>">
            <i class="menu-icon mdi mdi-account-circle"></i>Data User
          </a>
        </li>
      </ul>
    </div>
  </li>
  <li class="nav-item <?php echo e(Request::is('transaksi/create') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('transaksi.create')); ?>">
      <i class="menu-icon mdi mdi-laptop-mac"></i>
      <span class="menu-title">App Transaksi</span>
    </a>
  </li>
  <li class="nav-item <?php echo e(Request::is('transaksi') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('transaksi.index')); ?>">
      <i class="menu-icon mdi mdi-file-document"></i>
      <span class="menu-title">Transaksi Pinjam</span>
    </a>
  </li>
  <li class="nav-item <?php echo e(Request::is('transaksi-kembali') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('transaksi.kembali')); ?>">
      <i class="menu-icon mdi mdi-clipboard-check"></i>
      <span class="menu-title">Transaksi Kembali</span>
    </a>
  </li>
  <li class="nav-item <?php echo e(Request::is('laporan/trs') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(url('laporan/trs')); ?>">
      <i class="menu-icon mdi mdi-printer"></i>
      <span class="menu-title">Laporan</span>
    </a>
  </li>
  <?php endif; ?>
</ul><?php /**PATH D:\Project Freelance\Teman\KerjaPraktek-Indri\Revisi v1\perpus _indri_2\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>