<?php $__env->startSection('js'); ?>
<script type="text/javascript">
  $(document).ready(function() {
    $('#table-transaksi').DataTable({
      "iDisplayLength": 50,

    });

  });
</script>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-lg-12">
    <?php if(Session::has('message')): ?>
    <div class="alert alert-<?php echo e(Session::get('message_type')); ?>" id="waktu2" style="margin-top:10px;"><?php echo e(Session::get('message')); ?></div>
    <?php endif; ?>
  </div>
</div>
<div class="row" style="margin-top: 20px;">
  <div class="col-lg-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-header">
        <h4 class="card-title">DATA TRANSAKSI</h4>
      </div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-striped" id="table-transaksi">
            <thead>
              <tr>
                <th>
                  Kode
                </th>
                <th>
                  Peminjam
                </th>
                <th>
                  Tgl Pinjam
                </th>
                <th>
                  Tgl Hrs Kembali
                </th>
                <th>
                  Tgl Dikembalikan
                </th>
                <th>
                  Status
                </th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td class="py-1">
                  <a href="<?php echo e(route('transaksi.show', $data->id)); ?>">
                    <?php echo e($data->kode_transaksi); ?>

                  </a>
                </td>
                <td>
                  <?php if($data->mahasiswa_id == ''): ?>
                  <?php echo e($data->dosen->nama); ?>

                  <?php else: ?>
                  <?php echo e($data->mahasiswa->nama); ?>

                  <?php endif; ?>
                </td>
                <td>
                  <?php echo e(date('d/m/y', strtotime($data->tgl_pinjam))); ?>

                </td>
                <td>
                  <?php echo e(date('d/m/y', strtotime($data->tgl_kembali))); ?>

                </td>
                <td>
                  <?php if($data->status == 'kembali'): ?>
                  <?php echo e(date('d/m/y', strtotime($data->tgl_pengembalian))); ?>

                  <?php else: ?>
                  ---- -- --
                  <?php endif; ?>
                </td>
                <td>
                  <?php if($data->status == 'pinjam'): ?>
                  <label class="badge badge-warning">Pinjam</label>
                  <?php else: ?>
                  <label class="badge badge-success">Kembali</label>
                  <?php endif; ?>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
        
      </div>
    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal fade bd-example-modal-lg" id="myModalDetail" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content" style="background: #fff;">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Cari Buku</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <table id="lookup" class="table table-bordered table-hover table-striped">
          <thead>
            <tr>
              <th>Judul</th>
              <th>ISBN</th>
              <th>Pengarang</th>
              <th>Tahun</th>
              <th>Stok</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $bukus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="pilih" data-buku_id="<?php echo $data->id; ?>" data-buku_judul="<?php echo $data->judul; ?>">
              <td><?php if($data->cover): ?>
                <img src="<?php echo e(url('images/buku/'. $data->cover)); ?>" alt="image" style="margin-right: 10px;" />
                <?php else: ?>
                <img src="<?php echo e(url('images/buku/default.png')); ?>" alt="image" style="margin-right: 10px;" />
                <?php endif; ?>
                <?php echo e($data->judul); ?>

              </td>
              <td><?php echo e($data->isbn); ?></td>
              <td><?php echo e($data->pengarang); ?></td>
              <td><?php echo e($data->tahun_terbit); ?></td>
              <td><?php echo e($data->jumlah_buku); ?></td>
              <td><a href="#" id="addcart" data-idbuku="<?php echo e($data->id); ?>" data-url="<?php echo e(route('cart.store', $data->id)); ?>" data-token="<?php echo e(@csrf_token()); ?>" class="btn btn-success">Pilih</a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project Freelance\Teman\KerjaPraktek-Indri\Revisi v1\perpus _indri_2\resources\views/transaksi/index.blade.php ENDPATH**/ ?>