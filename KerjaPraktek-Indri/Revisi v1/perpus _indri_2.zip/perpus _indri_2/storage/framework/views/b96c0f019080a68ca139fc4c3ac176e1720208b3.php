<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12 d-flex align-items-stretch grid-margin">
        <div class="row flex-grow">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Keterangan</h4>
                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="kode_transaksi" class="col-md-12 control-label">Nama Peminjam</label>
                                    <div class="col-md-12">
                                        <?php $__currentLoopData = $mahas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <input id="nama" type="text" class="form-control" name="nama" value="<?php echo e($link->nama); ?>" required readonly="">
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="kode_transaksi" class="col-md-12 control-label">Tgl Dikembalikan</label>
                                    <div class="col-md-12">
                                        <input id="denda" type="text" class="form-control" name="denda" value="<?php echo e(date('d/m/y', strtotime($denda->tgl_pengembalian))); ?>" required readonly="">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="kode_transaksi" class="col-md-12 control-label">Denda</label>
                                    <div class="col-md-12">
                                        <input id="denda" type="text" class="form-control" name="denda" value="<?php echo e($denda->denda); ?>" required readonly="">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="kode_transaksi" class="col-md-12 control-label">Keterlambatan</label>
                                    <div class="col-md-12">
                                        <input id="terlambat" type="text" class="form-control" name="terlambat" value="<?php echo e($denda->terlambat); ?> Hari" required readonly="">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <h4 class="card-title">Data Item</h4>

                        <div class="table-responsive">
                            <table class="table table-striped" id="table">
                                <thead>
                                    <tr>
                                        <th>
                                            Nama Buku
                                        </th>
                                        <th>
                                            Kategori Buku
                                        </th>
                                        <th>
                                            Tgl Pinjam
                                        </th>
                                        <th>
                                            Tgl Kembali
                                        </th>
                                        <th>
                                            Qty
                                        </th>
                                        <th>
                                            Status
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="py-1">
                                            <?php echo e($d->judul); ?>

                                        </td>
                                        <td>
                                            <?php echo e($d->nama_kategori_buku); ?>

                                        </td>
                                        <td>
                                            <?php echo e(date('d/m/y', strtotime($d->tgl_pinjam))); ?>

                                        </td>
                                        <td>
                                            <?php echo e(date('d/m/y', strtotime($d->tgl_kembali))); ?>

                                        </td>
                                        <td>
                                            <?php echo e($d->qty); ?>

                                        </td>
                                        <td>
                                            <?php if($d->status == 'pinjam'): ?>
                                            <label class="badge badge-warning">Pinjam</label>
                                            <?php else: ?>
                                            <label class="badge badge-success">Kembali</label>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KerjaPraktek-Indri\perpus _indri_2\resources\views/transaksi/show.blade.php ENDPATH**/ ?>