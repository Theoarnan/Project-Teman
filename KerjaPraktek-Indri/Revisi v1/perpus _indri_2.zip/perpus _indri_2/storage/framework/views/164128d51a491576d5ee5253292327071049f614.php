<tr data-id="" style="text-align:center">
    <td class="fbarcode"></td>
    <td></td>
    <td id="qty" style="text-align:center;"></td>
    <td style="text-align:center;">
        <button id="hapus-keranjang" data-keranjangid="" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i> [DEL]</button>
    </td>
</tr><?php /**PATH D:\KerjaPraktek-Indri\perpus _indri_2\resources\views\transaksi\cart.blade.php ENDPATH**/ ?>