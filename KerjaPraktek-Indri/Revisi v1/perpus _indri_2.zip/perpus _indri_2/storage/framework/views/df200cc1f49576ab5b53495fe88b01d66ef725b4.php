<?php $__env->startSection('js'); ?>

<script type="text/javascript">
    $(document).ready(function () {
        $(".users").select2();
    });
</script>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

<form method="POST" action="<?php echo e(route('mahasiswa.store')); ?>" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <div class="row">
        <div class="col-md-12 d-flex align-items-stretch grid-margin">
            <div class="row flex-grow">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Mahasiswa Baru</h4>

                            <div class="form-group<?php echo e($errors->has('nama') ? ' has-error' : ''); ?>">
                                <label for="nama" class="col-md-4 control-label">Nama</label>
                                <div class="col-md-6">
                                    <input id="nama" type="text" class="form-control" name="nama"
                                        value="<?php echo e(old('nama')); ?>" required>
                                    <?php if($errors->has('nama')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('nama')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('nim') ? ' has-error' : ''); ?>">
                                <label for="nim" class="col-md-4 control-label">NIM</label>
                                <div class="col-md-6">
                                    <input id="nim" type="number" class="form-control" name="nim"
                                        value="<?php echo e(old('nim')); ?>" maxlength="8" required>
                                    <?php if($errors->has('nim')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('nim')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('tempat_lahir') ? ' has-error' : ''); ?>">
                                <label for="tempat_lahir" class="col-md-4 control-label">Tempat Lahir</label>
                                <div class="col-md-6">
                                    <input id="tempat_lahir" type="text" class="form-control" name="tempat_lahir"
                                        value="<?php echo e(old('tempat_lahir')); ?>" required>
                                    <?php if($errors->has('tempat_lahir')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('tempat_lahir')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('tgl_lahir') ? ' has-error' : ''); ?>">
                                <label for="tgl_lahir" class="col-md-4 control-label">Tanggal Lahir</label>
                                <div class="col-md-6">
                                    <input id="tgl_lahir" type="date" class="form-control" name="tgl_lahir"
                                        value="<?php echo e(old('tgl_lahir')); ?>" required>
                                    <?php if($errors->has('tgl_lahir')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('tgl_lahir')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('level') ? ' has-error' : ''); ?>">
                                <label for="level" class="col-md-4 control-label">Jenis Kelamin</label>
                                <div class="col-md-6">
                                    <select class="form-control" name="jk" required="">
                                        <option value=""></option>
                                        <option value="L">Laki - Laki</option>
                                        <option value="P">Perempuan</option>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('alamat_mahasiswa') ? ' has-error' : ''); ?>">
                                <label for="alamat_mahasiswa" class="col-md-4 control-label">Alamat Mahasiswa</label>
                                <div class="col-md-6">
                                    <input id="alamat_mahasiswa" type="text" class="form-control" name="alamat_mahasiswa"
                                        value="<?php echo e(old('alamat_mahasiswa')); ?>" required>
                                    <?php if($errors->has('alamat_mahasiswa')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('alamat_mahasiswa')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                <label for="email" class="col-md-4 control-label">Email</label>
                                <div class="col-md-6">
                                    <input id="email" type="text" class="form-control" name="email"
                                        value="<?php echo e(old('email')); ?>" required>
                                    <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('prodi') ? ' has-error' : ''); ?>">
                                <label for="prodi" class="col-md-4 control-label">Prodi</label>
                                <div class="col-md-6">
                                    <select class="form-control" name="prodi" required="">
                                        <option value=""></option>
                                        <option value="TI">Teknik Informatika</option>
                                        <option value="SI">Sistem Informasi</option>
                                        <option value="KM">Kesehatan Masyarakat</option>
                                    </select>
                                </div>
                            </div>

                            
                            <button type="submit" class="btn btn-primary" id="submit">
                                Submit
                            </button>
                            <button type="reset" class="btn btn-danger">
                                Reset
                            </button>
                            <a href="<?php echo e(route('mahasiswa.index')); ?>" class="btn btn-light pull-right">Back</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project Freelance\Teman\KerjaPraktek-Indri\Revisi v1\perpus _indri_2\resources\views/mahasiswa/create.blade.php ENDPATH**/ ?>