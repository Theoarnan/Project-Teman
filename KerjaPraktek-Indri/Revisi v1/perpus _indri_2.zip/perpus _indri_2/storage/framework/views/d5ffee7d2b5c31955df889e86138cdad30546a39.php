<?php $__env->startSection('js'); ?>

<script type="text/javascript">
    $(document).ready(function () {
        $(".users").select2();
    });
</script>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12 d-flex align-items-stretch grid-margin">
        <div class="row flex-grow">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Detail <b><?php echo e($data->nama); ?></b></h4>
                        <form class="forms-sample">
                            <div class="form-group">
                                <div class="col-md-6">
                                    <img class="product" width="200" height="200" <?php if($data->user->gambar): ?>
                                    src="<?php echo e(asset('images/user/'.$data->user->gambar)); ?>" <?php endif; ?> />
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('nama') ? ' has-error' : ''); ?>">
                                <label for="nama" class="col-md-4 control-label">Nama</label>
                                <div class="col-md-6">
                                    <input id="nama" type="text" class="form-control" name="nama"
                                        value="<?php echo e($data->nama); ?>" readonly>
                                    <?php if($errors->has('nama')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('nama')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group<?php echo e($errors->has('alamat_mahasiswa') ? ' has-error' : ''); ?>">
                                <label for="alamat_mahasiswa" class="col-md-4 control-label">Alamat</label>
                                <div class="form-group<?php echo e($errors->has('alamat_mahasiswa') ? ' has-error' : ''); ?>">
                                <label for="alamat_mahasiswa" class="col-md-4 control-label">Alamat Mahasiswa</label>
                                <div class="form-group<?php echo e($errors->has('alamat_mahasiswa') ? ' has-error' : ''); ?>">
                                <label for="alamat_mahasiswa" class="col-md-4 control-label">Alamat Mahasiswa</label>
                                
                                <div class="col-md-6">
                                    <input id="alamat_mahasiswa" type="text" class="form-control" name="alamat_mahasiswa"
                                        value="<?php echo e(old('alamat_mahasiswa')); ?>" required>
                                    <?php if($errors->has('alamat_mahasiswa')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('alamat_mahasiswa')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label for="email" class="col-md-4 control-label">E-Mail Address</label>
                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" name="email" value="<?php echo e($data->email); ?>" required readonly="">
                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                            </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('nim') ? ' has-error' : ''); ?>">
                                <label for="nim" class="col-md-4 control-label">NIM</label>
                                <div class="col-md-6">
                                    <input id="nim" type="number" class="form-control" name="nim"
                                        value="<?php echo e($data->nim); ?>" maxlength="8" readonly>
                                    <?php if($errors->has('nim')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('nim')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('tempat_lahir') ? ' has-error' : ''); ?>">
                                <label for="tempat_lahir" class="col-md-4 control-label">Tempat Lahir</label>
                                <div class="col-md-6">
                                    <input id="tempat_lahir" type="text" class="form-control" name="tempat_lahir"
                                        value="<?php echo e($data->tempat_lahir); ?>" readonly>
                                    <?php if($errors->has('tempat_lahir')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('tempat_lahir')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('tgl_lahir') ? ' has-error' : ''); ?>">
                                <label for="tgl_lahir" class="col-md-4 control-label">Tanggal Lahir</label>
                                <div class="col-md-6">
                                    <input id="tgl_lahir" type="text" class="form-control" name="tgl_lahir"
                                        value="<?php echo e(date('d F Y', strtotime($data->tgl_lahir))); ?>" readonly>
                                    <?php if($errors->has('tgl_lahir')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('tgl_lahir')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('level') ? ' has-error' : ''); ?>">
                                <label for="level" class="col-md-4 control-label">Jenis Kelamin</label>
                                <div class="col-md-6">
                                    <select class="form-control" name="jk" required="" disabled="">
                                        <option value=""></option>
                                        <option value="L" <?php echo e($data->jk === "L" ? "selected" : ""); ?>>Laki - Laki</option>
                                        <option value="P" <?php echo e($data->jk === "P" ? "selected" : ""); ?>>Perempuan</option>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('prodi') ? ' has-error' : ''); ?>">
                                <label for="prodi" class="col-md-4 control-label">Prodi</label>
                                <div class="col-md-6">
                                    <select class="form-control" name="prodi" required="" disabled="">
                                        <option value=""></option>
                                        <option value="TI" <?php echo e($data->prodi === "TI" ? "selected" : ""); ?>>Teknik
                                            Informatika</option>
                                        <option value="SI" <?php echo e($data->prodi === "SI" ? "selected" : ""); ?>>Sistem Informasi
                                        </option>
                                        <option value="KM" <?php echo e($data->prodi === "KM" ? "selected" : ""); ?>>Kesehatan
                                            Masyarakat</option>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('user_id') ? ' has-error' : ''); ?> "
                                style="margin-bottom: 20px;">
                                <label for="user_id" class="col-md-4 control-label">User Login</label>
                                <div class="col-md-6">
                                    <input id="tgl_lahir" type="text" class="form-control" name="tgl_lahir"
                                        value="<?php echo e($data->user->username); ?>" readonly="">
                                </div>
                            </div>
                            <a href="<?php echo e(route('mahasiswa.index')); ?>" class="btn btn-light pull-right">Back</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KerjaPraktek-Indri\perpus _indri_2\resources\views\mahasiswa\show.blade.php ENDPATH**/ ?>