<?php $__env->startSection('js'); ?>

<script type="text/javascript">
    $(document).ready(function () {
        $(".users").select2();
    });
</script>

<script type="text/javascript">
    function readURL() {
        var input = this;
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                $(input).prev().attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }

    $(function () {
        $(".uploads").change(readURL)
        $("#f").submit(function () {
            // do ajax submit or just classic form submit
            //  alert("fake subminting")
            return false
        })
    })
</script>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

<form method="POST" action="<?php echo e(route('buku.store')); ?>" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <div class="row">
        <div class="col-md-12 d-flex align-items-stretch grid-margin">
            <div class="row flex-grow">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Tambah Buku baru</h4>

                            <div class="form-group<?php echo e($errors->has('judul') ? ' has-error' : ''); ?>">
                                <label for="judul" class="col-md-4 control-label">Judul</label>
                                <div class="col-md-6">
                                    <input id="judul" type="text" class="form-control" name="judul"
                                        value="<?php echo e(old('judul')); ?>" required>
                                    <?php if($errors->has('judul')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('judul')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('npm') ? ' has-error' : ''); ?>">
                                <label for="isbn" class="col-md-4 control-label">ISBN</label>
                                <div class="col-md-6">
                                    <input id="isbn" type="number" class="form-control" name="isbn"
                                        value="<?php echo e(old('isbn')); ?>" required>
                                    <?php if($errors->has('isbn')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('isbn')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('pengarang') ? ' has-error' : ''); ?>">
                                <label for="pengarang" class="col-md-4 control-label">Pengarang</label>
                                <div class="col-md-6">
                                    <input id="pengarang" type="text" class="form-control" name="pengarang"
                                        value="<?php echo e(old('pengarang')); ?>" required>
                                    <?php if($errors->has('pengarang')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('pengarang')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('penerbit') ? ' has-error' : ''); ?>">
                                <label for="penerbit" class="col-md-4 control-label">Penerbit</label>
                                <div class="col-md-6">
                                    <input id="penerbit" type="text" class="form-control" name="penerbit"
                                        value="<?php echo e(old('penerbit')); ?>" required>
                                    <?php if($errors->has('penerbit')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('penerbit')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('tahun_terbit') ? ' has-error' : ''); ?>">
                                <label for="tahun_terbit" class="col-md-4 control-label">Tahun Terbit</label>
                                <div class="col-md-6">
                                    <input id="tahun_terbit" type="number" maxlength="4" class="form-control"
                                        name="tahun_terbit" value="<?php echo e(old('tahun_terbit')); ?>" required>
                                    <?php if($errors->has('tahun_terbit')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('tahun_terbit')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('jumlah_buku') ? ' has-error' : ''); ?>">
                                <label for="jumlah_buku" class="col-md-4 control-label">Jumlah Buku</label>
                                <div class="col-md-6">
                                    <input id="jumlah_buku" type="number" maxlength="4" class="form-control"
                                        name="jumlah_buku" value="<?php echo e(old('jumlah_buku')); ?>" required>
                                    <?php if($errors->has('jumlah_buku')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('jumlah_buku')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('deskripsi') ? ' has-error' : ''); ?>">
                                <label for="deskripsi" class="col-md-4 control-label">Deskripsi</label>
                                <div class="col-md-6">
                                    <input id="deskripsi" type="text" class="form-control" name="deskripsi"
                                        value="<?php echo e(old('deskripsi')); ?>">
                                    <?php if($errors->has('deskripsi')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('deskripsi')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-6">
                                    <label for="kategori_id">Kategori Buku</label>
                                    <select name="kategori_id" class="form-control" required>
                                        <option selected disabled>Pilih Kategori Buku</option>
                                        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <option value="<?php echo e($category->id); ?>"><?php echo e($category->nama_kategori_buku); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="email" class="col-md-4 control-label">Cover</label>
                                <div class="col-md-6">
                                    <img width="200" height="200" />
                                    <input type="file" class="uploads form-control" style="margin-top: 20px;"
                                        name="cover">
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary" id="submit">Submit</button>
                            <button type="reset" class="btn btn-danger"> Reset</button>
                            <a href="<?php echo e(route('buku.index')); ?>" class="btn btn-light pull-right">Back</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KerjaPraktek-Indri\perpus _indri_2\resources\views\buku\create.blade.php ENDPATH**/ ?>