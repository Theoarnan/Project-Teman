<?php $__env->startSection('js'); ?>

<script type="text/javascript">
    $(document).ready(function () {
        $(".users").select2();
    });
</script>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('dosen.update', $data->id)); ?>" method="post" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <?php echo e(method_field('put')); ?>

    <div class="row">
        <div class="col-md-12 d-flex align-items-stretch grid-margin">
            <div class="row flex-grow">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Edit Dosen</h4>

                            <div class="form-group<?php echo e($errors->has('nama') ? ' has-error' : ''); ?>">
                                <label for="nama" class="col-md-4 control-label">Nama</label>
                                <div class="col-md-6">
                                    <input id="nama" type="text" class="form-control" name="nama"
                                        value="<?php echo e($data->nama); ?>" required>
                                    <?php if($errors->has('nama')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('nama')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('nidn') ? ' has-error' : ''); ?>">
                                <label for="nidn" class="col-md-4 control-label">NIDN</label>
                                <div class="col-md-6">
                                    <input id="nidn" type="number" class="form-control" name="nidn"
                                        value="<?php echo e($data->nidn); ?>" maxlength="8" required>
                                    <?php if($errors->has('nidn')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('nidn')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('tempat_lahir') ? ' has-error' : ''); ?>">
                                <label for="tempat_lahir" class="col-md-4 control-label">Tempat Lahir</label>
                                <div class="col-md-6">
                                    <input id="tempat_lahir" type="text" class="form-control" name="tempat_lahir"
                                        value="<?php echo e($data->tempat_lahir); ?>" required>
                                    <?php if($errors->has('tempat_lahir')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('tempat_lahir')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('tgl_lahir') ? ' has-error' : ''); ?>">
                                <label for="tgl_lahir" class="col-md-4 control-label">Tanggal Lahir</label>
                                <div class="col-md-6">
                                    <input id="tgl_lahir" type="date" class="form-control" name="tgl_lahir"
                                        value="<?php echo e($data->tgl_lahir); ?>" required>
                                    <?php if($errors->has('tgl_lahir')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('tgl_lahir')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('level') ? ' has-error' : ''); ?>">
                                <label for="level" class="col-md-4 control-label">Jenis Kelamin</label>
                                <div class="col-md-6">
                                    <select class="form-control" name="jk" required="">
                                        <option value=""></option>
                                        <option value="L" <?php echo e($data->jk === "L" ? "selected" : ""); ?>>Laki - Laki</option>
                                        <option value="P" <?php echo e($data->jk === "P" ? "selected" : ""); ?>>Perempuan</option>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('level') ? ' has-error' : ''); ?>">
                                <label for="level" class="col-md-4 control-label">Program Studi</label>
                                <div class="col-md-6">
                                    <select class="form-control" name="ps" required="">
                                        <option value=""></option>
                                        <option value="I" <?php echo e($data->ps === "I" ? "selected" : ""); ?>>Informatika</option>
                                        <option value="T" <?php echo e($data->ps === "T" ? "selected" : ""); ?>>Teknik Sipil</option>
                                        <option value="F" <?php echo e($data->ps === "F" ? "selected" : ""); ?>>Fisika</option>
                                        <option value="M" <?php echo e($data->ps === "M" ? "selected" : ""); ?>>Manajemen</option>
                                        <option value="A" <?php echo e($data->ps === "A" ? "selected" : ""); ?>>Akuntansi</option>
                                        <option value="P" <?php echo e($data->ps === "P" ? "selected" : ""); ?>>Pendidikan Agama Kristen</option>
                                        <option value="MG" <?php echo e($data->ps === "MG" ? "selected" : ""); ?>>Musik Gereja</option>
                                        <option value="TH" <?php echo e($data->ps === "TH" ? "selected" : ""); ?>>Theologia Konseling Kristen</option>
                                    </select>
                                </div>
                            </div>
                 
                            <button type="submit" class="btn btn-primary" id="submit">
                                Ubah
                            </button>
                            <button type="reset" class="btn btn-danger">
                                Reset
                            </button>
                            <a href="<?php echo e(route('dosen.index')); ?>" class="btn btn-light pull-right">Back</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KerjaPraktek-Indri\perpus _indri_2\resources\views\dosen\edit.blade.php ENDPATH**/ ?>