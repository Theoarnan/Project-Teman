<?php $__env->startSection('js'); ?>

<script type="text/javascript">
    $(document).ready(function () {
        $(".users").select2();
    });
</script>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

<form method="POST" action="<?php echo e(route('dosen.store')); ?>" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <div class="row">
        <div class="col-md-12 d-flex align-items-stretch grid-margin">
            <div class="row flex-grow">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Tambah Dosen baru</h4>

                            <div class="form-group<?php echo e($errors->has('nama') ? ' has-error' : ''); ?>">
                                <label for="nama" class="col-md-4 control-label">Nama</label>
                                <div class="col-md-6">
                                    <input id="nama" type="text" class="form-control" name="nama"
                                        value="<?php echo e(old('nama')); ?>" required>
                                    <?php if($errors->has('nama')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('nama')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('nidn') ? ' has-error' : ''); ?>">
                                <label for="nidn" class="col-md-4 control-label">NIDN</label>
                                <div class="col-md-6">
                                    <input id="nidn" type="number" class="form-control" name="nidn"
                                        value="<?php echo e(old('nidn')); ?>" maxlength="8" required>
                                    <?php if($errors->has('nidn')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('nidn')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('tempat_lahir') ? ' has-error' : ''); ?>">
                                <label for="tempat_lahir" class="col-md-4 control-label">Tempat Lahir</label>
                                <div class="col-md-6">
                                    <input id="tempat_lahir" type="text" class="form-control" name="tempat_lahir"
                                        value="<?php echo e(old('tempat_lahir')); ?>" required>
                                    <?php if($errors->has('tempat_lahir')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('tempat_lahir')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('tgl_lahir') ? ' has-error' : ''); ?>">
                                <label for="tgl_lahir" class="col-md-4 control-label">Tanggal Lahir</label>
                                <div class="col-md-6">
                                    <input id="tgl_lahir" type="date" class="form-control" name="tgl_lahir"
                                        value="<?php echo e(old('tgl_lahir')); ?>" required>
                                    <?php if($errors->has('tgl_lahir')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('tgl_lahir')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('level') ? ' has-error' : ''); ?>">
                                <label for="level" class="col-md-4 control-label">Jenis Kelamin</label>
                                <div class="col-md-6">
                                    <select class="form-control" name="jk" required="">
                                        <option value=""></option>
                                        <option value="L">Laki - Laki</option>
                                        <option value="P">Perempuan</option>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('level') ? ' has-error' : ''); ?>">
                                <label for="level" class="col-md-4 control-label">Program Studi</label>
                                <div class="col-md-6">
                                    <select class="form-control" name="program_studi" required="">
                                        <option value=""></option>
                                        <option value="Informatika">Informatika</option>
                                        <option value="Teknik Sipil">Teknik Sipil</option>
                                        <option value="Fisika">Fisika</option>
                                        <option value="Manajemen">Manajemen</option>
                                        <option value="Akuntasi">Akuntansi</option>
                                        <option value="Pendidikan Agama Kristen">Pendidikan Agama Kristen</option>
                                        <option value="Musik Gereja">Musik Gereja</option>
                                        <option value="Theologia Konseling Kristen">Theologia Konseling Kristen</option>
                                    </select>
                                </div>
                            </div>

                            
                            <button type="submit" class="btn btn-primary" id="submit">
                                Submit
                            </button>
                            <button type="reset" class="btn btn-danger">
                                Reset
                            </button>
                            <a href="<?php echo e(route('dosen.index')); ?>" class="btn btn-light pull-right">Back</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KerjaPraktek-Indri\perpus _indri_2\resources\views/dosen/create.blade.php ENDPATH**/ ?>